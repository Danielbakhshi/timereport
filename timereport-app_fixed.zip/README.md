# TimeReport

Internal time tracking app connected to Supabase.

## What I changed

- The app now shows the real Supabase/Vercel connection error instead of only saying `Connection error`.
- The browser console now logs the failed Supabase request, status code, and response body.
- Added `supabase-setup.sql`, which creates the tables, Row Level Security policies, and starter accounts the app needs.
- Added optional support for Vercel/Vite environment variables:
  - `VITE_SUPABASE_URL`
  - `VITE_SUPABASE_ANON_KEY`

The hardcoded Supabase values already in `src/App.jsx` are still used as a fallback, so you do not have to set environment variables immediately.

## Local development

```bash
npm install
npm run dev
```

## Deploy through GitHub + Vercel

1. Upload/push this updated project to the same GitHub repository connected to Vercel.
2. Vercel should redeploy automatically.
3. After deploy, test the site again.

## Supabase setup

In Supabase:

1. Open your Supabase project.
2. Go to **SQL Editor**.
3. Click **New query**.
4. Copy everything from `supabase-setup.sql`.
5. Paste it into the SQL editor.
6. Click **Run**.

Starter test accounts created by the SQL file:

| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Employee | `anna` | `anna123` |
| Employee | `erik` | `erik123` |

## Important security note

This version is okay for a private prototype, but it is not production-secure. The app currently checks passwords in the browser and uses permissive Supabase `anon` policies so the app can work without Supabase Auth.

Before using this with real employee/client data, switch the login system to Supabase Auth or move password checking to a server-side API/Edge Function.

## How to read the next error

After deploying this fixed version, if login still fails, the red error box will show the actual reason. Common examples:

- `401` or `403`: Supabase key or Row Level Security policy issue.
- `relation "users" does not exist`: the `users` table has not been created; run `supabase-setup.sql`.
- `column ... does not exist`: the table exists but its columns do not match the app.
- `Could not reach Supabase`: wrong Supabase URL, inactive project, or network/DNS problem.
